/*
  MQTT Communication
*/

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "esp_wifi.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "protocol_examples_common.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"

#include "lwip/sockets.h"
#include "lwip/dns.h"
#include "lwip/netdb.h"

#include "esp_log.h"
#include "mqtt_client.h"

#include "driver/gpio.h"
#include "driver/adc.h"
#include "esp_adc_cal.h"
#include "driver/ledc.h"
#include "driver/pcnt.h"
//#include "string.h"


// Global Variables for ADC
esp_mqtt_client_handle_t client;
esp_adc_cal_characteristics_t *adc_chars;

// Global Variables for publishing


// Global Variables for subscribing
int control_status=0;
float nivel_status=0.0;

// Global Constants
#define DEFAULT_VREF  	1100
#define LED_GPIO 		2
#define MQTT_SERVER 	"mqtt://192.168.187.185:1883"
#define SAMPLING_PERIOD 30

#define PCNT_INPUT_SIG_IO   15  // Pulse Input GPIO
#define PCNT_INPUT_CTRL_IO  5  // Control GPIO HIGH=count up, LOW=count down
#define LEDC_OUTPUT_IO      18 // Output GPIO of a sample 1 Hz pulse generator
//#define MEASUREMENT_PERIOD	15 // Measurement period in seconds
#define K_FACTOR			7.5  // Flow sensor K factor
#define RELAY_OUTPUT        2  //Salida de control de bomba

ledc_timer_config_t ledc_timer;
ledc_channel_config_t ledc_channel;
static void ledc_init(void);
static void pcnt_init(int unit);

// Published MQTT TOPICS
#define MQTT_TOPIC_CAUDAL "Equipo8/caudal"

// Subscribed MQTT TOPICS
#define MQTT_TOPIC_LEVEL   "Equipo8/nivel"
#define MQTT_TOPIC_CONTROL "Equipo8/control"

// Functions definitions for MQTT
static esp_err_t mqtt_event_handler_cb(esp_mqtt_event_handle_t event);
static void mqtt_event_handler(void *handler_args, esp_event_base_t base, long int event_id, void *event_data);
static void mqtt_app_start(void);
static void mqtt_init(void);

// Functions definitions for ADC/GPIO
void init_ADC(void);
void init_GPIO(void);

//--------------------------------------------------------
// Main Program
//--------------------------------------------------------
void app_main(void)
{
	char str_caudal[10];

    mqtt_init();
    mqtt_app_start();
    init_ADC();
    init_GPIO();
    
    int pcnt_unit = PCNT_UNIT_0;
    int16_t count = 0;
    float flow_rate=0.0;

	/* Set the GPIO as a push/pull output */
    gpio_reset_pin(RELAY_OUTPUT);
    gpio_set_direction(RELAY_OUTPUT, GPIO_MODE_OUTPUT);

    /* Initialize PPCNT functions */
    pcnt_init(pcnt_unit);
    pcnt_counter_pause(pcnt_unit);

    /* Initialize LEDC to generate sample pulse signal */
    //ledc_init();

    printf("Starting...\n");
	gpio_set_level(RELAY_OUTPUT,0);
	//pcnt_counter_clear(pcnt_unit);
	pcnt_counter_resume(pcnt_unit);
	pcnt_counter_clear(pcnt_unit);

    while(1){
		
		if((count)<=(450*nivel_status)){
	        /* Read pulses */
	        //pcnt_counter_pause(pcnt_unit);
	        pcnt_get_counter_value(pcnt_unit, &count);
	        //printf("Number of pulses: %d in %d seconds\n",count,MEASUREMENT_PERIOD);
	        printf("Number of pulses: %d",count);
	        /* Calculate flow rate in L/min */
	        //flow_rate=(float)count/(MEASUREMENT_PERIOD*K_FACTOR);
	        flow_rate=(float)count/(1*K_FACTOR);
	        printf("Flow rate: %5.2f L/min\n",flow_rate);
	        sprintf(str_caudal,"%6.2f", flow_rate);
	        printf("----------- Data sent to MQTT Broker ------------\n");
        	esp_mqtt_client_publish(client, MQTT_TOPIC_CAUDAL, str_caudal, 0, 1, 0);
        	printf("Sent publish successful to %s\n", MQTT_TOPIC_CAUDAL);
	    }
		else{
			printf("Apagando relay\n");
			gpio_set_level(RELAY_OUTPUT,1);      
       }
		
    	// Sampling period loop delay
    	vTaskDelay( SAMPLING_PERIOD*1000 / portTICK_PERIOD_MS);
    }
}


//-------------------------------------------------
// Configure GPIO
//-------------------------------------------------
void init_GPIO(void)
{
	gpio_reset_pin(LED_GPIO);
	gpio_set_direction(LED_GPIO, GPIO_MODE_OUTPUT);
}

//-------------------------------------------------
// Configure ADC
//-------------------------------------------------
void init_ADC(void) {
	//Configure ADC
	adc1_config_width(ADC_WIDTH_BIT_12);
	adc1_config_channel_atten(ADC1_CHANNEL_6, ADC_ATTEN_DB_11);
	//Characterize ADC at particular attenuation
	adc_chars = calloc(1, sizeof(esp_adc_cal_characteristics_t));
	esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_11, ADC_WIDTH_BIT_12, DEFAULT_VREF, adc_chars);
}

//--------------------------------------------------------
// MQTT App Start
//--------------------------------------------------------
static void mqtt_app_start(void)
{
    const esp_mqtt_client_config_t mqtt_cfg = {
       .broker.address.uri = MQTT_SERVER,
    };

    client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, client);
    esp_mqtt_client_start(client);
}

//--------------------------------------------------------
// MQTT Init
//--------------------------------------------------------
static void mqtt_init(void)
{
	printf("[APP] Startup..\n");
    printf("[APP] Free memory: %ld bytes\n", esp_get_free_heap_size());
    printf("[APP] IDF version: %s\n", esp_get_idf_version());

    nvs_flash_init();
    esp_netif_init();
    esp_event_loop_create_default();
    example_connect();
}

//--------------------------------------------------------
// MQTT Event Handler
//--------------------------------------------------------
static esp_err_t mqtt_event_handler_cb(esp_mqtt_event_handle_t event)
{
    esp_mqtt_client_handle_t client = event->client;
    int msg_id;
    char topic[80];
    char data[20];

    // your_context_t *context = event->context;
    switch (event->event_id) {
        case MQTT_EVENT_CONNECTED:
        	printf("MQTT_EVENT_CONNECTED\n");
            msg_id = esp_mqtt_client_subscribe(client, MQTT_TOPIC_LEVEL, 0);
            printf("Sent subscribe successful to %s, msg_id=%d\n", MQTT_TOPIC_LEVEL, msg_id);
            msg_id = esp_mqtt_client_subscribe(client, MQTT_TOPIC_CONTROL, 0);
            printf("Sent subscribe successful to %s, msg_id=%d\n", MQTT_TOPIC_CONTROL, msg_id);
            break;
        case MQTT_EVENT_DISCONNECTED:
        	printf("MQTT_EVENT_DISCONNECTED\n");
            break;
        case MQTT_EVENT_SUBSCRIBED:
        	printf("MQTT_EVENT_SUBSCRIBED, msg_id=%d\n", event->msg_id);
            break;
        case MQTT_EVENT_UNSUBSCRIBED:
            printf("MQTT_EVENT_UNSUBSCRIBED, msg_id=%d\n", event->msg_id);
            break;
        case MQTT_EVENT_PUBLISHED:
        	printf("MQTT_EVENT_PUBLISHED, msg_id=%d\n", event->msg_id);
            break;
        case MQTT_EVENT_DATA:
        	printf("----------- Data received from MQTT Broker ------------\n");
            printf("TOPIC=%.*s\r\n", event->topic_len, event->topic);
            printf("DATA=%.*s\r\n", event->data_len, event->data);
            strncpy(topic,event->topic,event->topic_len);
            strncpy(data,event->data,event->data_len);
			topic[event->topic_len]=0;
			data[event->data_len]=0;
            if (strcmp(topic,MQTT_TOPIC_CONTROL)==0){
        		printf("Detected topic: %s\n",MQTT_TOPIC_CONTROL);
            	control_status=atoi(data);
            	if(control_status==0){
            		gpio_set_level(LED_GPIO, 0);
            		printf("Turn off LED\n");
            	}
            	else if (control_status==1){
            		gpio_set_level(LED_GPIO, 1);
            		printf("Turn on LED\n");
            	}
            }
            if (strcmp(topic,MQTT_TOPIC_LEVEL)==0){
        		printf("Detected topic: %s\n",MQTT_TOPIC_LEVEL);
            	nivel_status=atof(data);
        		printf("Level value: %6.2f\n",nivel_status);
            }
            break;

        case MQTT_EVENT_ERROR:
        	printf("MQTT_EVENT_ERROR\n");
            break;
        default:
        	printf("Other event id:%d\n", event->event_id);
            break;
    }
    return ESP_OK;
}

//--------------------------------------------------------
// MQTT Event Handler
//--------------------------------------------------------
static void mqtt_event_handler(void *handler_args, esp_event_base_t base, long int event_id, void *event_data)
{
    printf("Event dispatched from event loop base=%s, event_id=%ld\n", base, event_id);
    mqtt_event_handler_cb(event_data);
}


static void ledc_init(void)
{
    // Prepare and then apply the LEDC PWM timer configuration    
    ledc_timer.speed_mode       = LEDC_LOW_SPEED_MODE;
    ledc_timer.timer_num        = LEDC_TIMER_0;
    ledc_timer.duty_resolution  = LEDC_TIMER_10_BIT;
    ledc_timer.freq_hz          = 50;  // set output frequency at 50 Hz
    ledc_timer.clk_cfg 			= LEDC_AUTO_CLK;
    ledc_timer_config(&ledc_timer);

    // Prepare and then apply the LEDC PWM channel configuration
    ledc_channel.speed_mode = LEDC_LOW_SPEED_MODE;
    ledc_channel.channel    = LEDC_CHANNEL_0;
    ledc_channel.timer_sel  = LEDC_TIMER_0;
    ledc_channel.intr_type  = LEDC_INTR_DISABLE;
    ledc_channel.gpio_num   = LEDC_OUTPUT_IO;
    ledc_channel.duty       = 100; // set duty at about 10%
    ledc_channel.hpoint     = 0;
    ledc_channel_config(&ledc_channel);
}

/* Initialize PCNT functions:
 *  - configure and initialize PCNT
 *  - set up the input filter
 */
static void pcnt_init(int unit)
{
    /* Prepare configuration for the PCNT unit */
    pcnt_config_t pcnt_config = {
        // Set PCNT input signal and control GPIOs
        .pulse_gpio_num = PCNT_INPUT_SIG_IO,
        .ctrl_gpio_num = PCNT_INPUT_CTRL_IO,
        .channel = PCNT_CHANNEL_0,
        .unit = unit,
        // What to do on the positive / negative edge of pulse input?
        .pos_mode = PCNT_COUNT_INC,   // Count up on the positive edge
        .neg_mode = PCNT_COUNT_DIS,   // Keep the counter value on the negative edge
        // What to do when control input is low or high?
        .lctrl_mode = PCNT_MODE_REVERSE, // Reverse counting direction if low
        .hctrl_mode = PCNT_MODE_KEEP,    // Keep the primary counter mode if high
    };
    /* Initialize PCNT unit */
    pcnt_unit_config(&pcnt_config);
    /* Configure and enable the input filter */
    pcnt_set_filter_value(unit, 100);
    pcnt_filter_enable(unit);
}
